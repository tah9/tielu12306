<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
	.btn{
		background-color: #3c99f9;
		height: 2.2em;
		line-height: 2.2em;
		color: white;
		border-radius: 3px;
		text-align: center;
		width: 85%;
		margin: 1em 7.5% 8px 7.5%;
	}
</style>
